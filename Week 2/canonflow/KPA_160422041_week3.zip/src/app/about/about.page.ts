import { Component, OnInit } from '@angular/core';
// import { IonContent, IonItem, IonLabel, IonList } from '@ionic/angular/standalone';

@Component({
  selector: 'app-about',
  templateUrl: './about.page.html',
  styleUrls: ['./about.page.scss'],
  standalone: false,
  // imports: [IonContent, IonItem, IonLabel, IonList]
})
export class AboutPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
