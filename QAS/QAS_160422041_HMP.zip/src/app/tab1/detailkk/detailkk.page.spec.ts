import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DetailkkPage } from './detailkk.page';

describe('DetailkkPage', () => {
  let component: DetailkkPage;
  let fixture: ComponentFixture<DetailkkPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailkkPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
